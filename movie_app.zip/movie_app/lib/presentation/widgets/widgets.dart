// Widgets exports
export 'movie_card.dart';
export 'movie_poster_widget.dart';
export 'movie_card_shimmer.dart';
export 'movie_section.dart';
export 'error_widget.dart';
export 'loading_widget.dart';
export 'movix_title_widget.dart';
